package com.mycompany.appucard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
