package com.mycompany.ucard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
